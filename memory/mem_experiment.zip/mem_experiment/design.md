# Multi-GPU Managed-Memory Experiment

## Purpose

Build a small program, independent of SuiteSparse:GraphBLAS, that proves one
array can be:

1. allocated through RAPIDS Memory Manager (RMM),
2. initialized and read by the CPU,
3. addressed through the same pointer by every available GPU, and
4. modified by multiple GPUs with the final values observed by the CPU.

Implementation note: the final portable experiment uses `cudaMallocManaged`
directly rather than RMM so that it can be copied to a lab machine with only
the CUDA toolkit. RMM's `managed_memory_resource` uses this same CUDA managed
memory mechanism, so the memory-access and synchronization results remain
applicable to the GraphBLAS RMM path.

The experiment is about correctness and CUDA semantics, not performance. It
should make synchronization and memory placement explicit so that its results
can guide the later GraphBLAS matrix and vector work.

## Important terminology

"Allocate an array on the CPU" can mean two different things:

- Ordinary pageable host allocation (`malloc` or `new`): portable CPU memory,
  but not a pointer that arbitrary GPUs can directly dereference.
- CUDA managed allocation (`cudaMallocManaged`): one virtual address usable by
  the CPU and capable GPUs; CUDA migrates or maps its pages as processors use
  them.

RMM's `rmm::mr::managed_memory_resource` uses CUDA managed memory. This is the
appropriate resource for the proof of concept. The CPU will initialize and
verify the allocation, but RMM/CUDA will own it. Pinned host memory and device
memory solve different problems and should not be substituted in the first
experiment.

Pointer accessibility, current physical placement, and simultaneous access are
also separate properties:

- A managed pointer can be valid for all processors even when its pages are
  currently resident near only one processor.
- `cudaMemPrefetchAsync` changes likely placement; it does not create a second
  coherent copy of the allocation.
- A stream or device synchronization is required before another processor may
  consume results from an asynchronous kernel.
- True overlapping CPU/GPU or multi-GPU access depends on device and platform
  managed-memory capabilities. The baseline test must remain valid without
  overlap.

## Proposed directory

The eventual implementation can remain entirely inside this directory:

```text
mem_experiment/
    CMakeLists.txt
    main.cu
    design.md
```

Do not link GraphBLAS or `rmm_wrap`. Using RMM directly keeps the experiment
small and prevents GraphBLAS allocation tracking, JIT code, or matrix logic
from affecting the result.

## Program structure

Use one translation unit, `main.cu`, containing:

- a CUDA error-checking helper,
- a kernel that validates CPU initialization and writes a GPU-specific value,
- a small per-device state object containing a stream and slice boundaries,
- capability reporting,
- allocation and memory-advice setup,
- kernel launch and synchronization, and
- CPU-side verification.

The default array should contain enough elements to span many managed-memory
pages, for example 16 Mi elements of `std::uint64_t` (128 MiB). Accept an
optional element count on the command line so small and large cases can be
tested without recompilation.

## Allocation lifetime

The implemented portable version allocates directly through CUDA:

```cpp
std::uint64_t* values = nullptr;
cudaMallocManaged(&values, bytes);
```

This deliberately avoids an RMM build dependency on the lab machine. RMM's
managed resource delegates to CUDA managed allocation, so this proves the
shared-memory and synchronization semantics needed by the RMM-backed
GraphBLAS path.

The following RMM form remains useful for a later integration comparison, but
is not used by this standalone executable.

Construct the RMM resource and allocate from it directly:

```cpp
rmm::mr::managed_memory_resource managed_resource;
std::size_t bytes = element_count * sizeof(std::uint64_t);
auto* values = static_cast<std::uint64_t*>(
    managed_resource.allocate(bytes, rmm::cuda_stream_view{}));
```

The exact call signature should be adjusted to the RMM version selected by the
build. This repository currently requests RMM 26.06.00; its API should be the
reference when implementing the experiment.

Keep `managed_resource` alive until all streams are synchronized and `values`
has been deallocated. Deallocate with the same resource, byte count, and a
synchronized stream. A small RAII owner is acceptable, but a raw pointer with a
clearly delimited cleanup block is simpler for this one-file experiment.

Do not put a separate RMM pool in front of the managed resource initially. A
pool can obscure when pages are actually returned and introduces resource
lifetime questions unrelated to the access experiment. A follow-up test may
wrap the managed resource in `rmm::mr::pool_memory_resource` to match the
GraphBLAS configuration after the basic behavior is proven.

## Capability checks

At startup, call `cudaGetDeviceCount`. The program should print `SKIP` and exit
successfully when no CUDA device exists. One GPU is enough to validate
CPU/GPU access, but two or more are required for the central multi-GPU result.

For each GPU, print at least:

- device index and name,
- `cudaDevAttrManagedMemory`,
- `cudaDevAttrConcurrentManagedAccess`,
- `cudaDevAttrPageableMemoryAccess`, and
- peer-access results against every other selected GPU from
  `cudaDeviceCanAccessPeer`.

Managed memory does not require enabling peer access merely to use the managed
pointer. Peer topology still matters for placement and performance, so report
it rather than making it a pass condition.

If a selected device does not support managed memory, print a clear unsupported
message and do not launch this experiment on that device. Run the baseline on
the remaining supported devices. Require at least two supported devices before
claiming that the multi-GPU proof passed.

`cudaDevAttrConcurrentManagedAccess == 0` does not necessarily invalidate the
ordered baseline. It means the program should not claim that kernels on
multiple GPUs safely overlapped while accessing the allocation. In that case,
launch and synchronize one GPU at a time.

## Data partition

Divide the array into contiguous, non-overlapping slices, one per participating
GPU. Give any remainder to the last GPU. This avoids data races and avoids
intentional page ping-pong between GPUs.

Each element begins with a deterministic CPU value:

```cpp
values[i] = cpu_pattern(i);
```

GPU `d` receives `[begin, end)` and executes:

```cpp
__global__ void check_and_stamp(
    std::uint64_t* values,
    std::size_t begin,
    std::size_t end,
    int device,
    unsigned long long* mismatch_count)
{
    std::size_t i = begin + blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= end) return;

    // First prove this GPU can read values initialized by the CPU.
    if (values[i] != cpu_pattern(i)) {
        atomicAdd(mismatch_count, 1ULL);
    }

    // Then leave an unambiguous per-device value for CPU verification.
    values[i] = gpu_pattern(device, i);
}
```

`cpu_pattern` and `gpu_pattern` must be `__host__ __device__` functions so the
CPU verifier and GPU kernel use exactly the same formulas. Keep the patterns
simple, deterministic, and dependent on the global index. Allocate one managed
mismatch counter per GPU, or one managed array of counters, and initialize it
to zero on the CPU before any launch.

This partition models sparse GraphBLAS arrays well: `p`, `h`, `i`, `b`, and `x`
are independent allocations in GraphBLAS, while each individual allocation can
be partitioned into ranges for GPU work.

## Baseline execution sequence

The baseline is deliberately ordered. It proves portable coherence without
assuming simultaneous managed access.

1. Select all devices that report managed-memory support.
2. Create one non-default stream while each device is current. Retain the
   device ID beside the stream because streams belong to a CUDA context/device.
3. Allocate the array and mismatch counters with one RMM managed resource.
4. Initialize every element and counter from the CPU.
5. Confirm `cudaPointerGetAttributes(values)` reports
   `cudaMemoryTypeManaged`. Print the pointer once on the CPU and pass exactly
   that pointer value to every kernel.
6. For device `d`, make `d` current with `cudaSetDevice(d)`.
7. Optionally call `cudaMemAdvise(..., cudaMemAdviseSetAccessedBy, d)` for the
   complete allocation. Treat advice errors as errors rather than silently
   ignoring them.
8. Prefetch only device `d`'s slice to `d` on that device's stream. If the
   installed CUDA version uses the newer location-based prefetch API, isolate
   that difference in a small helper selected by `CUDART_VERSION`.
9. Launch `check_and_stamp` for the slice on the same stream and immediately
   call `cudaGetLastError` to detect launch errors.
10. For the maximally portable baseline, synchronize that stream before moving
    to the next GPU.
11. After every GPU has completed, prefetch the complete array and counters to
    `cudaCpuDeviceId`, then synchronize the stream used for that prefetch.
12. On the CPU, require all mismatch counters to be zero and require each
    element to equal `gpu_pattern(owner_device, i)`.
13. Deallocate only after all streams have synchronized, then destroy streams
    while their owning devices are current.

The explicit CPU prefetch in step 11 is a placement optimization and a useful
demonstration, not the operation that makes kernel writes logically complete.
The synchronization establishes completion. Managed memory permits the CPU to
fault pages back even without an explicit prefetch.

## Optional concurrent phase

After the ordered baseline passes, add `--concurrent` as a separate phase:

1. Restore the CPU pattern and zero the counters.
2. Require every participating GPU to report concurrent managed access.
3. Issue each slice prefetch and kernel in its owning device's stream without
   synchronizing between devices.
4. Synchronize every device stream.
5. Prefetch to the CPU and perform the same verification.

This phase tests overlapping kernels on disjoint managed-memory regions. It
must be reported separately from the baseline because support varies by GPU,
driver, operating system, and topology.

Do not have the CPU read or write the array while these kernels are active in
the first implementation. Concurrent CPU access is a third, more demanding
experiment and introduces ordinary C++ data-race concerns in addition to CUDA
managed-memory support. If needed later, test CPU/GPU overlap on disjoint pages
and coordinate ownership with CUDA events plus host synchronization.

## Error handling and diagnostics

Every CUDA call should be checked. A macro or small function should print:

- the CUDA expression,
- file and line,
- `cudaGetErrorName(status)`, and
- `cudaGetErrorString(status)`.

On failure, clean up resources that are known to be valid and return a nonzero
status. Avoid continuing after a failed prefetch or launch because a later
synchronization error otherwise hides the original operation.

Print a compact execution record such as:

```text
devices discovered: 4
participating devices: 0 1 2 3
allocation: 134217728 bytes at 0x...
mode: ordered
GPU 0 slice [0, 4194304): PASS
GPU 1 slice [4194304, 8388608): PASS
GPU 2 slice [8388608, 12582912): PASS
GPU 3 slice [12582912, 16777216): PASS
CPU verification: PASS (0 mismatches)
MULTI-GPU MANAGED MEMORY: PASS
```

Return codes should be:

- `0`: requested test passed, or skipped because CUDA is unavailable,
- `1`: CUDA/RMM/runtime failure,
- `2`: verification failure, and
- `3`: invalid command-line input.

## Build design

Use a standalone CMake project so this experiment can be configured without
building GraphBLAS. A minimal shape is:

```cmake
cmake_minimum_required(VERSION 3.25)
project(mem_experiment LANGUAGES CXX CUDA)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CUDA_STANDARD 17)
set(CMAKE_CUDA_STANDARD_REQUIRED ON)

find_package(CUDAToolkit REQUIRED)
find_package(rmm CONFIG REQUIRED)

add_executable(mem_experiment main.cu)
target_link_libraries(mem_experiment PRIVATE rmm::rmm CUDA::cudart)
```

Prefer an installed RMM package or an explicit `CMAKE_PREFIX_PATH` for the
first implementation. If reproducible dependency fetching is required, copy
the repository's CPM setup and pin RMM to the same 26.06.00 version; do not
silently select an arbitrary current release.

Example commands after implementation:

```sh
cmake -S mem_experiment -B mem_experiment/build \
    -DCMAKE_PREFIX_PATH=/path/to/rmm/install
cmake --build mem_experiment/build -j
./mem_experiment/build/mem_experiment
./mem_experiment/build/mem_experiment --elements 1048576 --concurrent
```

The implementation should print the CUDA runtime and driver versions and, if
available from build metadata, the RMM version. This makes results comparable
across development machines.

## Validation matrix

Run these cases and retain their output:

| Case | Purpose | Expected result |
| --- | --- | --- |
| One supported GPU, ordered | CPU/GPU managed access | Pass, but explicitly not a multi-GPU proof |
| Two or more GPUs, ordered | Required proof of concept | Every GPU and CPU verification pass |
| Two or more GPUs, concurrent | Overlap capability | Pass or capability-based skip |
| Tiny array | Boundary and empty-slice handling | Pass when elements are fewer than GPUs |
| Non-divisible element count | Partition remainder | Last slice verifies correctly |
| Large array | Page migration behavior | Pass or clear allocation failure |
| CUDA unavailable | Developer-machine behavior | Clean skip, no crash |

For the tiny-array case, skip devices assigned an empty slice rather than
launching a zero-block kernel.

Use `compute-sanitizer --tool memcheck` on at least the ordered multi-GPU case.
If the concurrent phase is implemented, also run `compute-sanitizer --tool
racecheck`, while recognizing that racecheck support and findings can vary for
multi-GPU managed memory.

## Success criteria

The concept is proven when, on a machine with at least two supported GPUs:

- RMM returns an allocation reported by CUDA as managed memory,
- the CPU initializes it without a copy,
- at least two GPUs read CPU-initialized values through the same pointer,
- those GPUs modify separate regions,
- the CPU observes every modification after explicit synchronization, and
- compute-sanitizer reports no invalid accesses in the ordered test.

The proof does not establish good performance, automatic load balancing, or
safe unsynchronized writes to the same elements. Those require separate design
work.

## Follow-up experiments

Only after the baseline passes:

1. Put an RMM pool over the managed resource to reproduce GraphBLAS allocation
   behavior and verify that allocation/deallocation device context is correct.
2. Represent a tiny CSR matrix with three separate managed arrays (`p`, `i`,
   and `x`) and assign rows to GPUs.
3. Compare no advice, `SetAccessedBy`, preferred-location advice, and explicit
   prefetching with Nsight Systems or managed-memory counters.
4. Test read-mostly metadata such as CSR row pointers with
   `cudaMemAdviseSetReadMostly` if all GPUs only read it.
5. Decide whether GraphBLAS needs an ownership/state tracker per allocation so
   every CPU or GPU consumer waits for the last writer before access.

The key GraphBLAS lesson should remain explicit: managed allocation supplies a
shared address space, but GraphBLAS must still track asynchronous work and
synchronize ownership transitions between CPU and GPU consumers.
