// Demonstrate coherent access to one CUDA managed allocation from the CPU and
// multiple GPUs. This file intentionally depends only on the CUDA runtime and
// the C++ standard library so it can be copied to an isolated CUDA machine.

#include <cuda_runtime.h>

#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <vector>

namespace {

constexpr std::size_t kDefaultElements = 16ULL * 1024ULL * 1024ULL;
constexpr int kThreadsPerBlock = 256;
constexpr int kRuntimeFailure = 1;
constexpr int kVerificationFailure = 2;
constexpr int kInvalidArguments = 3;

struct Options {
    std::size_t element_count = kDefaultElements;
    bool concurrent = false;
};

struct DeviceState {
    int id = -1;
    cudaDeviceProp properties{};
    int managed_memory = 0;
    int concurrent_managed_access = 0;
    int pageable_memory_access = 0;
    std::size_t begin = 0;
    std::size_t end = 0;
    cudaStream_t stream = nullptr;
};

// Keep patterns in one host/device function so CPU and GPU verification cannot
// accidentally drift apart. The constants make device ownership visible in a
// debugger while preserving enough index bits to catch partition mistakes.
__host__ __device__ std::uint64_t cpu_pattern(std::size_t index)
{
    return 0x4350550000000000ULL ^ static_cast<std::uint64_t>(index);
}

__host__ __device__ std::uint64_t gpu_pattern(int device, std::size_t index)
{
    return 0x4750550000000000ULL ^
           (static_cast<std::uint64_t>(static_cast<unsigned int>(device)) << 48) ^
           static_cast<std::uint64_t>(index);
}

__global__ void check_and_stamp(std::uint64_t* values,
                                std::size_t begin,
                                std::size_t end,
                                int device,
                                unsigned long long* mismatch_count)
{
    const std::size_t offset =
        static_cast<std::size_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const std::size_t index = begin + offset;
    if (index >= end) {
        return;
    }

    // Reading the CPU pattern proves that this GPU sees CPU-initialized data.
    if (values[index] != cpu_pattern(index)) {
        atomicAdd(mismatch_count + device, 1ULL);
    }

    // A GPU-specific pattern lets the CPU prove which GPU wrote each slice.
    values[index] = gpu_pattern(device, index);
}

bool check_cuda(cudaError_t status, const char* expression, const char* file,
                int line)
{
    if (status == cudaSuccess) {
        return true;
    }

    std::fprintf(stderr, "CUDA error at %s:%d\n  %s\n  %s: %s\n", file,
                 line, expression, cudaGetErrorName(status),
                 cudaGetErrorString(status));
    return false;
}

#define CUDA_TRY(expression)                                                   \
    do {                                                                       \
        if (!check_cuda((expression), #expression, __FILE__, __LINE__)) {      \
            return false;                                                      \
        }                                                                      \
    } while (false)

void print_usage(const char* program)
{
    std::printf(
        "Usage: %s [--elements N] [--concurrent] [--help]\n"
        "\n"
        "  --elements N   Number of uint64_t elements (default: %zu)\n"
        "  --concurrent   Also run overlapping kernels on all GPUs\n"
        "  --help         Print this message\n",
        program, kDefaultElements);
}

bool parse_size(const char* text, std::size_t* result)
{
    if (text == nullptr || text[0] == '\0' || text[0] == '-') {
        return false;
    }

    errno = 0;
    char* end = nullptr;
    const unsigned long long value = std::strtoull(text, &end, 10);
    if (errno == ERANGE || end == text || *end != '\0' || value == 0 ||
        value > std::numeric_limits<std::size_t>::max()) {
        return false;
    }

    *result = static_cast<std::size_t>(value);
    return true;
}

int parse_options(int argc, char** argv, Options* options)
{
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--help") == 0) {
            print_usage(argv[0]);
            return 1;
        }
        if (std::strcmp(argv[i], "--concurrent") == 0) {
            options->concurrent = true;
            continue;
        }
        if (std::strcmp(argv[i], "--elements") == 0 && i + 1 < argc) {
            if (!parse_size(argv[++i], &options->element_count)) {
                std::fprintf(stderr, "Invalid element count: %s\n", argv[i]);
                return -1;
            }
            continue;
        }

        std::fprintf(stderr, "Unknown or incomplete option: %s\n", argv[i]);
        print_usage(argv[0]);
        return -1;
    }
    return 0;
}

bool get_attribute(int* value, cudaDeviceAttr attribute, int device)
{
    return check_cuda(cudaDeviceGetAttribute(value, attribute, device),
                      "cudaDeviceGetAttribute", __FILE__, __LINE__);
}

bool discover_devices(std::vector<DeviceState>* devices)
{
    int count = 0;
    const cudaError_t count_status = cudaGetDeviceCount(&count);
    if (count_status == cudaErrorNoDevice || count_status == cudaErrorInsufficientDriver) {
        std::printf("SKIP: no usable CUDA device (%s)\n",
                    cudaGetErrorString(count_status));
        return true;
    }
    CUDA_TRY(count_status);

    std::printf("devices discovered: %d\n", count);
    for (int id = 0; id < count; ++id) {
        DeviceState state;
        state.id = id;
        CUDA_TRY(cudaGetDeviceProperties(&state.properties, id));
        if (!get_attribute(&state.managed_memory, cudaDevAttrManagedMemory, id) ||
            !get_attribute(&state.concurrent_managed_access,
                           cudaDevAttrConcurrentManagedAccess, id) ||
            !get_attribute(&state.pageable_memory_access,
                           cudaDevAttrPageableMemoryAccess, id)) {
            return false;
        }

        std::printf(
            "GPU %d: %s, compute %d.%d, managed=%d, concurrent-managed=%d, "
            "pageable-access=%d\n",
            id, state.properties.name, state.properties.major,
            state.properties.minor, state.managed_memory,
            state.concurrent_managed_access, state.pageable_memory_access);

        if (state.managed_memory) {
            devices->push_back(state);
        } else {
            std::printf("GPU %d excluded: managed memory is unsupported\n", id);
        }
    }

    for (const DeviceState& from : *devices) {
        for (const DeviceState& to : *devices) {
            if (from.id == to.id) {
                continue;
            }
            int can_access = 0;
            CUDA_TRY(cudaDeviceCanAccessPeer(&can_access, from.id, to.id));
            std::printf("peer access GPU %d -> GPU %d: %s\n", from.id, to.id,
                        can_access ? "yes" : "no");
        }
    }

    return true;
}

bool create_streams(std::vector<DeviceState>* devices)
{
    for (DeviceState& device : *devices) {
        CUDA_TRY(cudaSetDevice(device.id));
        CUDA_TRY(cudaStreamCreateWithFlags(&device.stream, cudaStreamNonBlocking));
    }
    return true;
}

bool synchronize_streams(const std::vector<DeviceState>& devices)
{
    for (const DeviceState& device : devices) {
        if (device.stream == nullptr) {
            continue;
        }
        CUDA_TRY(cudaSetDevice(device.id));
        CUDA_TRY(cudaStreamSynchronize(device.stream));
    }
    return true;
}

void destroy_streams(std::vector<DeviceState>* devices)
{
    for (DeviceState& device : *devices) {
        if (device.stream == nullptr) {
            continue;
        }
        cudaSetDevice(device.id);
        const cudaError_t status = cudaStreamDestroy(device.stream);
        if (status != cudaSuccess) {
            std::fprintf(stderr, "Could not destroy GPU %d stream: %s\n",
                         device.id, cudaGetErrorString(status));
        }
        device.stream = nullptr;
    }
}

// CUDA 13 introduced location-based prefetch parameters. Keep this API detail
// here so the rest of the experiment is identical across toolkit generations.
bool prefetch_async(void* pointer, std::size_t bytes, int destination,
                    cudaStream_t stream)
{
#if CUDART_VERSION >= 13000
    cudaMemLocation location{};
    if (destination == cudaCpuDeviceId) {
        location.type = cudaMemLocationTypeHost;
        location.id = 0;
    } else {
        location.type = cudaMemLocationTypeDevice;
        location.id = destination;
    }
    return check_cuda(
        cudaMemPrefetchAsync(pointer, bytes, location, 0, stream),
        "cudaMemPrefetchAsync", __FILE__, __LINE__);
#else
    return check_cuda(cudaMemPrefetchAsync(pointer, bytes, destination, stream),
                      "cudaMemPrefetchAsync", __FILE__, __LINE__);
#endif
}

bool advise_accessed_by(void* pointer, std::size_t bytes, int device)
{
#if CUDART_VERSION >= 13000
    cudaMemLocation location{};
    location.type = cudaMemLocationTypeDevice;
    location.id = device;
    return check_cuda(
        cudaMemAdvise(pointer, bytes, cudaMemAdviseSetAccessedBy, location),
        "cudaMemAdvise(SetAccessedBy)", __FILE__, __LINE__);
#else
    return check_cuda(
        cudaMemAdvise(pointer, bytes, cudaMemAdviseSetAccessedBy, device),
        "cudaMemAdvise(SetAccessedBy)", __FILE__, __LINE__);
#endif
}

void initialize_on_cpu(std::uint64_t* values, std::size_t element_count,
                       unsigned long long* mismatch_counts, int device_count)
{
    for (std::size_t i = 0; i < element_count; ++i) {
        values[i] = cpu_pattern(i);
    }
    for (int i = 0; i < device_count; ++i) {
        mismatch_counts[i] = 0;
    }
}

bool prepare_device_access(std::uint64_t* values, std::size_t value_bytes,
                           unsigned long long* mismatch_counts,
                           std::size_t mismatch_bytes,
                           const std::vector<DeviceState>& devices)
{
    for (const DeviceState& device : devices) {
        // Advice and explicit prefetch require concurrent managed access on
        // current CUDA platforms. Ordered access still works without them.
        if (!device.concurrent_managed_access) {
            std::printf("GPU %d: skipping memory advice; concurrent managed "
                        "access is unsupported\n",
                        device.id);
            continue;
        }
        CUDA_TRY(cudaSetDevice(device.id));
        if (!advise_accessed_by(values, value_bytes, device.id) ||
            !advise_accessed_by(mismatch_counts, mismatch_bytes, device.id)) {
            return false;
        }
    }
    return true;
}

bool launch_slice(std::uint64_t* values, DeviceState* device,
                  unsigned long long* mismatch_counts)
{
    const std::size_t count = device->end - device->begin;
    if (count == 0) {
        return true;
    }

    CUDA_TRY(cudaSetDevice(device->id));
    if (device->concurrent_managed_access &&
        !prefetch_async(values + device->begin, count * sizeof(*values),
                        device->id, device->stream)) {
        return false;
    }

    const std::size_t blocks_needed =
        (count + static_cast<std::size_t>(kThreadsPerBlock) - 1) /
        static_cast<std::size_t>(kThreadsPerBlock);
    if (blocks_needed > static_cast<std::size_t>(
                            std::numeric_limits<unsigned int>::max())) {
        std::fprintf(stderr, "GPU %d slice requires too many CUDA blocks\n",
                     device->id);
        return false;
    }

    check_and_stamp<<<static_cast<unsigned int>(blocks_needed),
                      kThreadsPerBlock, 0, device->stream>>>(
        values, device->begin, device->end, device->id, mismatch_counts);
    CUDA_TRY(cudaGetLastError());
    return true;
}

bool move_results_to_cpu(std::uint64_t* values, std::size_t value_bytes,
                         unsigned long long* mismatch_counts,
                         std::size_t mismatch_bytes, DeviceState* device)
{
    // The kernels are already complete before this call. Prefetch controls
    // placement and avoids page faults during CPU verification.
    CUDA_TRY(cudaSetDevice(device->id));
    if (device->concurrent_managed_access) {
        if (!prefetch_async(values, value_bytes, cudaCpuDeviceId,
                            device->stream) ||
            !prefetch_async(mismatch_counts, mismatch_bytes, cudaCpuDeviceId,
                            device->stream)) {
            return false;
        }
    }
    CUDA_TRY(cudaStreamSynchronize(device->stream));
    return true;
}

bool verify_results(const std::uint64_t* values, std::size_t element_count,
                    const unsigned long long* mismatch_counts,
                    const std::vector<DeviceState>& devices,
                    const char* mode)
{
    unsigned long long gpu_read_mismatches = 0;
    for (const DeviceState& device : devices) {
        gpu_read_mismatches += mismatch_counts[device.id];
        std::printf("GPU %d slice [%zu, %zu): %s (%llu input mismatches)\n",
                    device.id, device.begin, device.end,
                    mismatch_counts[device.id] == 0 ? "PASS" : "FAIL",
                    mismatch_counts[device.id]);
    }

    std::size_t cpu_mismatches = 0;
    constexpr std::size_t kMaximumReports = 8;
    for (const DeviceState& device : devices) {
        for (std::size_t i = device.begin; i < device.end; ++i) {
            const std::uint64_t expected = gpu_pattern(device.id, i);
            if (values[i] != expected) {
                if (cpu_mismatches < kMaximumReports) {
                    std::fprintf(stderr,
                                 "CPU mismatch at %zu: got 0x%016llx, expected "
                                 "0x%016llx from GPU %d\n",
                                 i, static_cast<unsigned long long>(values[i]),
                                 static_cast<unsigned long long>(expected),
                                 device.id);
                }
                ++cpu_mismatches;
            }
        }
    }

    const bool passed = gpu_read_mismatches == 0 && cpu_mismatches == 0;
    std::printf("CPU verification (%s): %s (%zu output mismatches)\n", mode,
                passed ? "PASS" : "FAIL", cpu_mismatches);
    return passed;
}

bool run_phase(const char* mode, bool concurrent, std::uint64_t* values,
               std::size_t element_count,
               unsigned long long* mismatch_counts,
               std::vector<DeviceState>* devices)
{
    const std::size_t value_bytes = element_count * sizeof(*values);
    const std::size_t mismatch_bytes =
        devices->size() == 0 ? 0 :
        (static_cast<std::size_t>(devices->back().id) + 1) *
            sizeof(*mismatch_counts);

    std::printf("mode: %s\n", mode);
    initialize_on_cpu(values, element_count, mismatch_counts,
                      static_cast<int>(mismatch_bytes /
                                       sizeof(*mismatch_counts)));

    for (DeviceState& device : *devices) {
        if (!launch_slice(values, &device, mismatch_counts)) {
            return false;
        }
        if (!concurrent) {
            CUDA_TRY(cudaStreamSynchronize(device.stream));
        }
    }

    if (concurrent && !synchronize_streams(*devices)) {
        return false;
    }
    if (!move_results_to_cpu(values, value_bytes, mismatch_counts,
                             mismatch_bytes, &devices->front())) {
        return false;
    }
    return verify_results(values, element_count, mismatch_counts, *devices,
                          mode);
}

}  // namespace

int main(int argc, char** argv)
{
    Options options;
    const int parse_result = parse_options(argc, argv, &options);
    if (parse_result > 0) {
        return 0;
    }
    if (parse_result < 0) {
        return kInvalidArguments;
    }
    if (options.element_count >
        std::numeric_limits<std::size_t>::max() / sizeof(std::uint64_t)) {
        std::fprintf(stderr, "Element count overflows the allocation size\n");
        return kInvalidArguments;
    }

    std::vector<DeviceState> devices;
    if (!discover_devices(&devices)) {
        return kRuntimeFailure;
    }
    if (devices.empty()) {
        std::printf("SKIP: no GPU reports managed-memory support\n");
        return 0;
    }

    int driver_version = 0;
    int runtime_version = 0;
    if (!check_cuda(cudaDriverGetVersion(&driver_version),
                    "cudaDriverGetVersion", __FILE__, __LINE__) ||
        !check_cuda(cudaRuntimeGetVersion(&runtime_version),
                    "cudaRuntimeGetVersion", __FILE__, __LINE__)) {
        return kRuntimeFailure;
    }
    std::printf("CUDA driver: %d, runtime: %d, compiled CUDART: %d\n",
                driver_version, runtime_version, CUDART_VERSION);

    const std::size_t active_count =
        options.element_count < devices.size() ? options.element_count
                                               : devices.size();
    devices.resize(active_count);
    const std::size_t elements_per_device =
        options.element_count / devices.size();
    const std::size_t remainder = options.element_count % devices.size();
    std::size_t next_element = 0;
    for (std::size_t position = 0; position < devices.size(); ++position) {
        devices[position].begin = next_element;
        next_element += elements_per_device;
        if (position < remainder) {
            ++next_element;
        }
        devices[position].end = next_element;
    }

    std::printf("participating devices:");
    for (const DeviceState& device : devices) {
        std::printf(" %d", device.id);
    }
    std::printf("\n");
    if (devices.size() < 2) {
        std::printf("NOTE: this validates CPU/GPU access but is not a "
                    "multi-GPU proof\n");
    }

    if (!create_streams(&devices)) {
        destroy_streams(&devices);
        return kRuntimeFailure;
    }

    std::uint64_t* values = nullptr;
    unsigned long long* mismatch_counts = nullptr;
    const std::size_t value_bytes = options.element_count * sizeof(*values);
    const std::size_t mismatch_count =
        static_cast<std::size_t>(devices.back().id) + 1;
    const std::size_t mismatch_bytes =
        mismatch_count * sizeof(*mismatch_counts);

    bool runtime_ok = check_cuda(cudaMallocManaged(&values, value_bytes),
                                 "cudaMallocManaged(values)", __FILE__,
                                 __LINE__) &&
                      check_cuda(cudaMallocManaged(&mismatch_counts,
                                                   mismatch_bytes),
                                 "cudaMallocManaged(mismatch_counts)",
                                 __FILE__, __LINE__);
    if (!runtime_ok) {
        if (values != nullptr) {
            cudaFree(values);
        }
        destroy_streams(&devices);
        return kRuntimeFailure;
    }

    cudaPointerAttributes attributes{};
    runtime_ok = check_cuda(cudaPointerGetAttributes(&attributes, values),
                            "cudaPointerGetAttributes", __FILE__, __LINE__);
    if (runtime_ok && attributes.type != cudaMemoryTypeManaged) {
        std::fprintf(stderr, "Allocation is not CUDA managed memory (type %d)\n",
                     static_cast<int>(attributes.type));
        runtime_ok = false;
    }

    std::printf("allocation: %zu bytes at %p (cudaMallocManaged)\n",
                value_bytes, static_cast<void*>(values));
    if (runtime_ok) {
        runtime_ok = prepare_device_access(values, value_bytes, mismatch_counts,
                                           mismatch_bytes, devices);
    }

    bool verification_ok = false;
    if (runtime_ok) {
        verification_ok = run_phase("ordered", false, values,
                                    options.element_count, mismatch_counts,
                                    &devices);
        if (!verification_ok) {
            std::fprintf(stderr, "Ordered managed-memory phase failed\n");
        }
    }

    if (runtime_ok && verification_ok && options.concurrent) {
        bool supported = true;
        for (const DeviceState& device : devices) {
            if (!device.concurrent_managed_access) {
                std::printf(
                    "SKIP concurrent phase: GPU %d does not report concurrent "
                    "managed access\n",
                    device.id);
                supported = false;
            }
        }
        if (supported) {
            verification_ok = run_phase("concurrent", true, values,
                                        options.element_count, mismatch_counts,
                                        &devices);
            if (!verification_ok) {
                std::fprintf(stderr, "Concurrent managed-memory phase failed\n");
            }
        }
    }

    // All work is complete before freeing managed memory or destroying streams.
    if (!synchronize_streams(devices)) {
        runtime_ok = false;
    }
    const bool freed_counts =
        check_cuda(cudaFree(mismatch_counts), "cudaFree(mismatch_counts)",
                   __FILE__, __LINE__);
    const bool freed_values = check_cuda(cudaFree(values), "cudaFree(values)",
                                         __FILE__, __LINE__);
    if (!freed_counts || !freed_values) {
        runtime_ok = false;
    }
    destroy_streams(&devices);

    if (!runtime_ok) {
        return kRuntimeFailure;
    }
    if (!verification_ok) {
        return kVerificationFailure;
    }

    std::printf("%s: PASS\n",
                devices.size() >= 2 ? "MULTI-GPU MANAGED MEMORY"
                                    : "CPU/GPU MANAGED MEMORY");
    return 0;
}
