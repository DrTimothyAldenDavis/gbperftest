# Multi-GPU Memory Experiment

This directory contains a standalone CUDA experiment for validating access to
one CUDA managed allocation from the CPU and multiple GPUs. It is intentionally
independent of SuiteSparse:GraphBLAS so that allocation, migration, and
synchronization behavior can be tested without GraphBLAS state or JIT code.

The production GraphBLAS path uses RMM's managed-memory resource. This isolated
program calls `cudaMallocManaged` directly, which provides the same underlying
CUDA allocation semantics without requiring RMM on the test machine.

See [`design.md`](design.md) for the detailed execution model, capability
checks, validation criteria, and planned follow-up experiments.

## Requirements

- A CUDA toolkit with `nvcc`
- A CUDA-capable system and driver
- GNU Make or a compatible `make`

No GraphBLAS, RMM, CMake, or third-party libraries are required. The executable
links only the CUDA runtime and uses the C++ standard library supplied with the
host compiler.

For the central proof, the machine should have at least two GPUs that support
CUDA managed memory. A one-GPU machine can still validate CPU/GPU access.

## Build

From this directory, use:

```sh
make
```

The default executable is `mem_experiment`.

The Makefile uses `/usr/local/cuda` as the default CUDA installation and builds
for H100 (`sm_90`) by default. CUDA 12 or newer is recommended for H100.
Override either setting when needed:

```sh
make CUDA_HOME=/opt/cuda
make GPU_ARCH=sm_80
```

If `nvcc` is already on `PATH`, it can be selected directly:

```sh
make NVCC=nvcc
```

Additional compile, preprocessor, or link flags can be appended without
editing the Makefile:

```sh
make NVCCFLAGS='-O0 -g -G -std=c++17' \
     LDLIBS=-lcudart
```

## Run

```sh
make run
```

Arguments can be passed with `ARGS`:

```sh
make run ARGS='--elements 1048576 --concurrent'
```

On the two-H100 machine, a useful first sequence is:

```sh
make
./mem_experiment
./mem_experiment --concurrent
compute-sanitizer --tool memcheck ./mem_experiment
```

The default allocation is 128 MiB. `--elements` counts 64-bit elements, not
bytes.

The ordered mode described in `design.md` should be the default. Concurrent
multi-GPU access should remain an explicit option because its support depends
on the GPUs, driver, operating system, and topology.

## Useful targets

| Command | Action |
| --- | --- |
| `make` | Build `mem_experiment` |
| `make run` | Build and run the experiment |
| `make clean` | Remove the executable and generated dependencies |
| `make print-config` | Print resolved compiler and installation paths |

The program returns `0` on success or a capability-based skip, `1` for a CUDA
runtime failure, `2` for a data verification failure, and `3` for invalid
arguments.

## Expected result

On a supported multi-GPU machine, a successful ordered run should demonstrate
that:

- `cudaMallocManaged` allocated CUDA managed memory,
- the CPU initialized the allocation,
- multiple GPUs read the CPU-initialized values through the same pointer,
- each GPU modified a disjoint region, and
- the CPU observed all modifications after explicit synchronization.

This establishes correctness of the shared address and ownership transitions;
it does not by itself establish good migration performance or safe
unsynchronized writes to shared elements.
